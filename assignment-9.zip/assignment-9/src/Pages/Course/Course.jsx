
const Course = () => {
    return (
        <div>
            <h2 className="text-3xl">This is Course</h2>
        </div>
    );
};

export default Course;