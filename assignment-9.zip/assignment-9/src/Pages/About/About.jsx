
const About = () => {
    return (
        <div>
            <h2 className="text-3xl">This is about</h2>
        </div>
    );
};

export default About;