
const ContactUs = () => {
    return (
        <div>
            <h2 className="text-3xl">This is Contact Us</h2>
        </div>
    );
};

export default ContactUs;