


const Social = () => {
  


  return (
    <div>
      <p>
        <button className="btn btn-ghost">Google</button>
      </p>
    </div>
  );
};

export default Social;
